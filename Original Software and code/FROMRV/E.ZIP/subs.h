void Check_Key();
void Default_Places();
void dly();
int feof_or_null(FILE *stream);
long get_long(FILE *stream);
int Keyboard(uint key, uint repeatCount, uint flags);
void load_places();
void load_stations();
void MoveWindowToTopOfList(int which);
void PrintInt(int value);
void save_stations();

