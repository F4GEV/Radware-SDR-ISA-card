//REGEN_FILEHEADING
//REGEN_FILEHEADING

     /********************************************************************
      *                                                                  *
      *   Source File: Spectrum.h                                        *
      *   Description: Header file for Spectrum application              *
      *   Date:        Fri Oct 02 17:42:35 1992                          *
      *                                                                  *
      ********************************************************************/

#ifndef __SPECTRUM__H
#define IDM_SWEEP_SPEED	109
#define IDM_STEP_SIZE	108
#define IDM_START_FREQUENCY	104
#define IDM_STOP_FREQUENCY	105
#define IDM_CENTER_FREQUENCY	106
#define IDM_FREQUENCY_SPAN	107
#define __SPECTRUM__H

//REGEN_HEADER
//REGEN_HEADER


//REGEN_VARS
//REGEN_VARS



#endif // __SPECTRUM__H
