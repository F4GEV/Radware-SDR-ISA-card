/*   Volume.dsp  */
/*   Version 0.1 slow AGC prototype */
/*   Version 0.2 faster AGC prototype 6/30/94 */

.MODULE/RAM        VOLUMEMOD;

#define PIO_I2C_CLOCK_HIGH 0x0202
#define PIO_I2C_CLOCK_LOW 0xfdfd
#define PIO_I2C_DATA_HIGH 0x0101
#define PIO_I2C_DATA_LOW 0xfefe
#define MICROSECOND_DELAY_COUNT 20
  /*  was 16 */
#define I2CDELAY 160
  /*  was 40 */
#define I2CDELAY2 320
#define BUFFER_LENGTH_SLOW_AGC 64
#define rtty_samples_per_bit 53

.VAR/DM/RAM rtty_samples_left;
.VAR/DM/RAM last_rtty_sample;
.VAR/DM/RAM temp;
.VAR/DM/RAM true_volume;
.VAR/DM/RAM volume;
.VAR/DM/RAM reg_l0;
.VAR/DM/RAM largest;
.VAR/DM/RAM error;
.VAR/DM/RAM PIO_reg_data;
.VAR/DM/RAM OFFSET;
.VAR/DM/RAM wanted_volume;
.VAR/DM/RAM I_Volume;
.VAR/CIRC slow_agc_values[BUFFER_LENGTH_SLOW_AGC];
.VAR/DM/RAM slow_agc_pnt;
.VAR/DM/RAM arctan_data[256];
.VAR/DM/RAM High_Pass_0;
.VAR/DM/RAM High_Pass_1;
.VAR/CIRC Offset_Array_1[64];
.VAR/CIRC Offset_Array_2[64];
.VAR/DM/RAM Offset_1_pnt; 
.VAR/DM/RAM Offset_2_pnt;
.VAR/DM/RAM/ABS=0x31c8 PIO_;
.VAR/DM/RAM save_flags[2];
.VAR/DM/RAM Transfer_Data[2];
.INIT       arctan_data: <arctan>;

.external RegSave;
.external RegRestore;
.external RegSave2;
.external RegRestore2;
.external UFilter_;
.external LFilter_;
.external FM_Filter_;
.external TalkOn_;
.external FM_Filter8;
.external FM_Filter9;
.external USB_BUFFER_;
.external put_word;
.external Buffer_Position;
.GLOBAL Offset_Array_1;
.GLOBAL Offset_Array_2;
.GLOBAL Offset_1_pnt;
.GLOBAL Offset_2_pnt;
.GLOBAL Transfer_Data;
.GLOBAL I_Volume;

.ENTRY CenterAll_;
.ENTRY ChangeVolume_;
.ENTRY Convert_RTTY_To_Bits_;
.ENTRY Convert_RTTY_To_Bits_2;
.ENTRY Costas;
.ENTRY RestoreVolume_;
.ENTRY GetVolume_;
.ENTRY GetError_;
.ENTRY ClearError_;
.ENTRY Change_I_;
.ENTRY ClearOffset_;
.ENTRY MultiplyByVolume_;
.ENTRY MultiplyAllByVolume_;
.ENTRY PSK_;
.ENTRY AGC_;
.ENTRY Adjust_I_;
.ENTRY MySetTone_;
.ENTRY SlowAGC_;
.ENTRY InitAGC_;
.ENTRY SSBAGC_;
.ENTRY FreqCal_;
.ENTRY Multiply_;
.ENTRY Mute_Samples_;
.ENTRY FreqCal2_;
.ENTRY FreqCal3_;
.ENTRY FreqCal4_;
.ENTRY HighPass_;
.ENTRY Pythagoras_;
.ENTRY Center_;
.ENTRY FM_;
.ENTRY FM2_;
.ENTRY FM3_;
.ENTRY CheckAnalog_;
.ENTRY Copy_Data_128_;
.ENTRY Copy_Data_256_;
.ENTRY Copy_Data_256_to_128_;
.ENTRY Copy_Data_128_to_256_;

Copy_Data_256_to_128_: CNTR = 128;
                       M0 = 2;
                       jump Copy_Data2;

Copy_Data_256_: CNTR = 256;
                jump Copy_Data;

Copy_Data_128_: CNTR = 128;
Copy_Data:      M0 = 1;
Copy_Data2:     I0 = AY1;
                I1 = AR;
                L0 = 0;
                L1 = 0;
                M1 = 1;
                do Copy_128 until CE;
                AR = DM(I0,M0);
Copy_128:       DM(I1,M1) = AR;
                rts;

Copy_Data_128_to_256_: CNTR = 128;
                       M0 = 1;
                       I0 = AY1;
                       I1 = AR;
                       L0 = 0;
                       L1 = 0;
                       M1 = 1;
                       do Copy_128_256 until CE;
                       AR = DM(I0,M0);
                       DM(I1,M1) = AR;
Copy_128_256:          DM(I1,M1) = AR;
                       rts;

InitAGC_:      I0 = ^slow_agc_values;
               M0 = 1;
               l0 = BUFFER_LENGTH_SLOW_AGC;
               CNTR = BUFFER_LENGTH_SLOW_AGC;
               AR = 0xFFFF;
               do initialize until CE;
initialize:    DM(I0,M0) = AR;
               dm(slow_agc_pnt) = I0;
               rts;

CheckAnalog_:  AX0 = dm(largest);
               AY0 = H#1000;
               AR = AX0-AY0;
               if ac jump check_up;
               AY0 = H#4000;
               AR = AX0+AY0;
               if ac jump check_down;
               AR = PASS 0;
check_end:     rts;
check_down:    AR = -1;
               jump check_end;
check_up:      AR = 1;
               jump check_end;

ChangeVolume_: dm(volume) = AR;
               dm(true_volume) = AR;
               dm(wanted_volume) = AR;
               ar = 0;
               dm(OFFSET) = AR;
               RTS;

Change_I_:      dm(I_Volume) = AR;
                rts;

RestoreVolume_: AR = 0;
                dm(OFFSET) = AR;
                AR = dm(true_volume);
                dm(volume) = AR;
                dm(wanted_volume) = AR;
                rts;

GetVolume_: AR = dm(largest);
            RTS;

ClearOffset_: AR = 0;
              dm(OFFSET) = AR;
              RTS;

ClearError_: AR = 0;
             dm(error) = AR;
             RTS;

GetError_: AR = dm(error);
           rts;

Adjust_I_: call RegSave;
           I0 = AR;
           M0 = 0;
           M1 = 2;
           L0 = 0;
           MY0 = dm(I_Volume);
           MX0 = dm(I0,M0);
           CNTR = 128;
           do I_Loop until CE;
           MR = MX0*MY0 (SU);
           SR = LSHIFT MR0 BY 1 (LO);
           SR = SR OR LSHIFT MR1 BY 1 (HI);
           dm(I0,M1) = SR1;
I_Loop:    MX0 = dm(I0,M0);
           call RegRestore;
           rts;

MultiplyAllByVolume_ : I0 = AR;
                       M0 = 1;
                       M1 = 0;
                       L0 = 0;
                       MY1 = dm(volume);
                       AY0 = DM(OFFSET);
                       CNTR = 256;
                       AR = DM(I0,M1);
                       do MultiplyAllLoop until CE;
                       AR = AR-AY0;
                       MR=AR*MY1(SS);
                       SR=LSHIFT MR0 BY -10 (LO);
                       SR=SR OR ASHIFT MR1 BY -10 (HI);
                       AF=PASS SR1;
                       IF GT JUMP MaxSineAll;
                       AF = AF+1;
                       IF LT JUMP MinSineAll;
                       AR=SR0;
ModVolumeAll:          DM(I0,M0) = AR;
MultiplyAllLoop:       AR = DM(I0,M1);
                       rts;

HighPass_: call RegSave;
           I0 = AR;
           M0 = 0;
           M1 = 1;
           L0 = 0;
           CNTR = 256;
           AY0 = DM(High_Pass_0);
           AY1 = DM(High_Pass_1);
           do HighPass2 Until CE;
           AR = DM(I0,M0);
           AR = AR-AY0;
           AY0 = DM(I0,M0);
           DM(I0,M1) = AR;
           AR = DM(I0,M0);
           AR = AR-AY1;
           AY1 = DM(I0,M0);
HighPass2: DM(I0,M1) = AR;
           DM(High_Pass_0) = AY0;
           DM(High_Pass_1) = AY1;
           call RegSave;
           rts;

CenterAll_: call RegSave;
            I0 = AR;
            AY1 = AR;
            call Calc_Offset;
            I2 = dm(Offset_1_pnt);
            call Average_Offset;
            dm(Offset_1_pnt) = I2;
            AY0 = MR1;
            AR = AY1+1;
            I0 = AR;
            call Calc_Offset;
            I2 = dm(Offset_2_pnt);
            call Average_Offset;
            dm(Offset_2_pnt) = I2;
            I0 = AY1;
            AY1 = MR1;
            M0 = 0;
            M1 = 1;
            L0 = 0;
            CNTR = 128;
            AR = DM(I0,M0);
            do CenterAll until CE;
            AR = AR-AY0;
            DM(I0,M1) = AR;
            AR = DM(I0,M0);
            AR = AR-AY1;
            DM(I0,M1) = AR;
CenterAll:  AR = DM(I0,M0);
/*            AX0 = 0;
            DM(OFFSET) = AX0;
*/            call RegRestore;
            rts;

Calc_Offset: M0 = 2;  /* I0 is sent to routine */
             L0 = 0;
             MY1 = 512;
             MR = 0;
             MX1 = DM(I0,M0);
             CNTR = 128;
             DO Calc_Off1 UNTIL CE;
Calc_Off1:   MR = MR+MX1*MY1 (SS), MX1 = DM(I0,M0);
             DM(OFFSET) = MR1;
             rts;

Average_Offset: M2 = 1;
                L2 = 64;
                MY1 = 0x0400;
                MX1 = DM(OFFSET);
                DM(I2,M2) = MX1;
                MR = 0;
                CNTR = 64;
                DO Average_Loop UNTIL CE;
Average_Loop:   MR = MR+MX1*MY1(SS),MX1 = DM(I2,M2);
                rts;

MinSineAll:        AR=H#8000;
                   dm(error)=AR;
                   jump ModVolumeAll;
MaxSineAll:        AR=H#7FFF;
                   dm(error)=AR;
                   jump ModVolumeAll;

MultiplyByVolume_: call RegSave;
                   MY1=dm(volume);
                   AY0= DM(OFFSET);
                   AR = AR-AY0;
                   MR=AR*MY1(SS);
                   SR=LSHIFT MR0 BY -10 (LO);
                   SR=SR OR ASHIFT MR1 BY -10 (HI);
                   AF=PASS SR1;
                   IF GT JUMP MaxSine;
                   AF = AF+1;
                   IF LT JUMP MinSine;
                   AR=SR0;
mod_volume:        AX0 = AR;
             /*      AX1 = dm(volume);
                   AY1 = dm(wanted_volume);
                   AR = AX1 - AY1;
                   if eq jump end_volume;
                   if ac jump inc_volume;
                   AY0 = 250;
                   AR = AR-AY0;
                   if ac jump eq_volume;
                   AR = AX1-AY0;
                   dm(volume) = AR;
                   jump end_volume;
eq_volume:         AR = dm(wanted_volume);
                   dm(volume) = AR;
                   jump end_volume;
inc_volume:    jump eq_volume;    AY0 = 250;
                   AR = AR+AY0;
                   if ac jump eq_volume;
                   AR = AX1+AY0;
                   dm(volume) = AR;
*/end_volume:        AR = AX0;
                   call RegRestore;
                   RTS;
MinSine:           AR=H#8000;
                   dm(error)=AR;
                   jump mod_volume;
MaxSine:           AR=H#7FFF;
                   dm(error)=AR;
                   jump mod_volume;

SlowAGC_:   call RegSave;      /* slow agc will keep volume at its lowest*/
/*            call AGC_;
*/            I0 = dm(slow_agc_pnt);M0 = 1;L0 = BUFFER_LENGTH_SLOW_AGC;
            AY0 = dm(wanted_volume);
            dm(I0,M0) = AY0;
            dm(slow_agc_pnt) = I0;
            CNTR = BUFFER_LENGTH_SLOW_AGC;
            do slow_agc until CE;
            AX0 = dm(I0,M0);
            AR = AX0-AY0;
            if ac jump slow_agc;
            AY0 = AX0;
slow_agc:   NOP;
            dm(wanted_volume) = AY0;
            dm(volume) = AY0;
            call RegRestore;
            rts;

SSBAGC_:    call RegSave;
            i0 = AR;
            l0 = 0;
            m0 = 2;
            CNTR = 128;
            MR0 = 0;
            MR1 = H#FFFF;
            AX0 = dm(i0,m0);
            AY1 = H#8000;    /* make numbers run from 0x0000 to 0xffff unsigned */
            do ssb_loop UNTIL CE;
            AF = AX0+AY1;
            AR = AF - MR0;
            if NOT AC jump ssb_not_hi;
            AR = PASS AF;
            MR0 = AR;
ssb_not_hi: AR = AF-MR1;
            if AC jump ssb_loop;
            AR = PASS AF;
            MR1 = AR;
ssb_loop:   AX0 = dm(i0,m0);
            AY0 = MR0;
            AR = AY0-MR1;
            dm(largest) = AR;
            AY1 = MR1;
            jump AF_BIG;   /* enter AGC loop at end of largest detection cycle */

AGC_:       call RegSave;
            i0 = AR;
            l0 = 0;
            m0 = 1;
            CNTR = 128; /*was 128, only look at one sideband due to DC shifts */
            MR0 = 0;
            MR1 = H#FFFF;
            SR0 = 0;
            SR1 = H#FFFF;
            AX0 = dm(i0,m0);
            AY1 = H#8000;    /* make numbers run from 0x0000 to 0xffff unsigned */
            do AGC_loop2 UNTIL CE;
            AF = AX0+AY1;
            AR = AF - MR0;
            if NOT AC jump not_high;
            AR = PASS AF;
            MR0 = AR;
not_high:   AR = AF-MR1;
            if AC jump AGC_loop;
            AR = PASS AF;
            MR1 = AR;
AGC_loop:   AX0 = dm(i0,m0);
            AF = AX0+AY1;
            AR = AF - SR0;
            if NOT AC jump not_high2;
            AR = PASS AF;
            SR0 = AR;
not_high2:  AR = AF-SR1;
            if AC jump AGC_loop2;
            AR = PASS AF;
            SR1 = AR;
AGC_loop2:  AX0 = dm(i0,m0);
            AY0 = SR0;
            AF = AY0-SR1;
            AY0 = MR0;
            AR = AY0-MR1;
            AX0 = AR;
            AR = AF-AR;
            if NOT AC jump AR_BIG;
            AR = PASS AF;
            dm(largest) = AR;
            AY1 = SR1;
            jump AF_BIG;
AR_BIG:     AR = AX0;
            dm(largest) = AR;
            AY1 = MR1;
AF_BIG:     AX0 = AR;
            SR = LSHIFT AR BY -1 (LO);
            AF = SR0+AY1;
            AX1 = H#8000;
            AR = AX1+AF;
            DM(OFFSET) = AR;
            AY0 = H#E800;
            AF = AY0-AX0;
            if ac jump not_hi;
            AX0 = H#E800;
not_hi:     AY0 = H#0800;
            AF = AY0-AX0;
            if not ac jump no_squelch;
            AX0 = H#0800;
no_squelch: SI = AX0;
            SR = LSHIFT SI BY 0 (LO);
            AX0 = SR0;
            SI = dm(true_volume);
            AY0 = dm(TalkOn_);
            AF = PASS AY0;
            if EQ jump RX_AGC;
            SR = LSHIFT SI BY 13 (LO);
            jump TX_AGC;
RX_AGC:     SR = LSHIFT SI BY 11 (LO);
TX_AGC:     AF = PASS SR1;
            AY0 = SR0;
            CALL divide;
            dm(wanted_volume) = AY0;
            dm(volume) = AY0;   /* remove volume for ramping */
restore:    call RegRestore;
            rts;

divide:     ASTAT = 0;
            DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            RTS;

sdivide:    DIVS AF,AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            DIVQ AX0; DIVQ AX0; DIVQ AX0;
            RTS;

Pythagoras_: call RegSave;
             MX0 = AR;
             MY0 = AR;
             MR = MX0*MY0 (SS);
             MX0 = AY1;
             MY0 = AY1;
             MR = MR+MX0*MY0 (SS);
             call sqrt;
/*             AR = AY1;
             if lt jump Pythagoras2;
*/             AR = SR1;
             call RegRestore;
             rts;
Pythagoras2: AY0 = 0;
             AR = AY0 - SR1;
             call RegRestore;
             rts;

Multiply_:  call RegSave;
            MX0 = AR;
            MY0 = AY1;
            MR = MX0*MY0(SS);
            SR = LSHIFT MR0 BY 8 (LO);
            SR = SR OR LSHIFT MR1 BY 8 (HI);
            AR = SR1;
            call RegRestore;
            rts;

FreqCal_:   call RegSave;   /* Costas Loop */
            i0 = AR;
            l0 = 0;
            m0 = 1;
            CNTR = 128;
            MR = 0;
            MY0 = DM(I0,M0);
            do FreqLoop UNTIL CE;
            MX0 = DM(I0,M0);
FreqLoop:   MR = MR+MX0*MY0(SS), MY0 = DM(I0,M0);
            AR = MR1;
            call RegRestore;
            rts;

Costas:      i0 = AR;
             i1 = AR;
             l0 = 0;
             l1 = 0;
             M1 = 1;
             CNTR = 128;
             MY0 = DM(I0,M1);
             do Costas_Loop UNTIL CE;
             MX0 = DM(I0,M1);
             MR = MX0*MY0(SS), MY0 = DM(I0,M1);
             DM(I1,M1) = MR1;
Costas_Loop: DM(I1,M1) = MR0;
             rts;

/*FreqCal4_:  call RegSave;
            i0 = AR;
            l0 = 0;
            m0 = 1;
            i1 = AY1;
            l1 = 0;
            AX0 = 10;     Set AX0 to an absurd quadrant
            CNTR = 128;
            AY1 = 0;
            do FreqLoop4 UNTIL CE;
            MY0 = DM(I0,M0);
            MX0 = DM(I1,M0);
            call quadrant;
            AY0 = AR;
            AF = AX0 - AY0;
            AR = AF-1;
            if eq jump Cal4Down;
            AR = AF+1;
            if ne jump FreqLoop4;
            AR = AY1+1;
            AY1 = AR;
            jump FreqLoop4;
Cal4Down:   AR = AY1-1;
            AY1 = AR;
FreqLoop4:   AX0 = AY0;
            AR = AY1;
            call RegRestore;
            rts;

quadrant:   AR= MX0;
            if pos jump quad12;
            ar=MY0;
            if pos jump quad4;
            ar = 3;
            rts;
quad4:      ar = 4;
            rts;
quad12:     ar = MY0;
            if pos jump quad1;
            ar = 2;
            rts;
quad1:      ar = 1;
            rts;
*/

FreqCal4_:  call RegSave;   /* Costas Loop */
            i0 = AR;
            l0 = 0;
            m0 = 1;
            i1 = AY1;
            l1 = 0;
            CNTR = 128;
            MR = 0;
            do FreqLoop4 UNTIL CE;
            AY0 = DM(I0,M0);
            AX1 = DM(I1,M0);
            AR = AX1-AY0;
            MX0 = AR;
            AR = AX1+AY0;
            MY0 = AR;
FreqLoop4:  MR = MR+MX0*MY0(SS);
            AR = MR1;
            AR = -AR;
/*            MX0 = 0x8000;
            MY0 = 0x8000;
            MR = MR+MX0*MY0(UU);
            MR = MR+MX0*MY0(UU);
            AF = PASS MR2;
            if eq jump dontmodify4;
            ar = 0;
*/dontmodify4: call RegRestore;
            rts;

FreqCal3_:  call RegSave;   /* Costas Loop */
            i0 = AR;
            l0 = 0;
            m0 = 1;
            i1 = AY1;
            l1 = 0;
            CNTR = 128;
            MR = 0;
            MY0 = DM(I0,M0);
            do FreqLoop3 UNTIL CE;
            MX0 = DM(I1,M0);
FreqLoop3:  MR = MR+MX0*MY0(SS), MY0 = DM(I0,M0);
            AR = MR1;
            MX0 = 0x8000;
            MY0 = 0x8000;
            MR = MR+MX0*MY0(UU);
            MR = MR+MX0*MY0(UU);
            AF = PASS MR2;
            if eq jump dontmodify;
            ar = 0;
/*            AY1 = H#0008;
            if LT jump Freql2;
            AF = AR - AY1;
            if GT jump dontmodify;
            AR = 1;
*/dontmodify: call RegRestore;
            rts;
/*Freql2:     AF = AR + AY1;
            if LE jump dontmodify;
            ar = -1;
            jump dontmodify;
*/
FreqCal2_:  call RegSave;
            AX1 = dm(volume);
            call SSBAGC_;
            AX0 = dm(largest);
            AR = AY1;
            call SSBAGC_;
            AY0 = dm(largest);
            dm(volume) = AX1;
            AR = AX0-AY0;
            call RegRestore;
            rts;

delay_I2C:             { delay for 2.5 uSec }
    CNTR = I2CDELAY;
    DO I2C_delay UNTIL CE;
  nop;
I2C_delay:
    nop;
    rts;

        {This routine delays N microseconds where N is passed in ax0}
delay_us_:
    cntr = ax0;
    do dw2 until CE;
    cntr = MICROSECOND_DELAY_COUNT;
    do dwait until CE;
dwait:
    nop;
dw2:
    nop;
    rts;

MySetTone_: call RegSave;
/*            SR0 = IMASK;
            dm(save_flags) = sr0;
            IMASK = 0;
            SR1 = dm(H#3FFE);
            dm(save_flags+1) = sr1;
            AX0 = H#7FFF;
            dm(0x3FFE) = AX0;
*/            ay0 = ar;
            ar = ay0;
            MY0 = 0;
            AY0 = 0xC0;
            AR = AR+AY0;
            SR = LSHIFT AR BY 8 (LO);
            MY1 = SR0;
            call MyI2CByte;
            call MyI2CByte;
            MY1 = 0xF000;
            call MyI2CByte;
            call MyI2CByte;
/*            sr0 = dm(save_flags);
            sr1 = dm(save_flags+1);
            IMASK = SR0;
            dm(H#3FFE) = SR1;
*/            call RegRestore;
            rts;

MyI2CByte:  call I2CStart;
            MR0 = 0x8200;
            call I2CLoadByte;
            MR0 = MY0;
            call I2CLoadByte;
            MR0 = MY1;
            call I2CLoadByte;
            call I2CStop;
            AY0 = MY0;
            AX0 = 0x0100;
            AR = AX0+AY0;
            MY0 = AR;
            rts;

I2CStart:   AR = 0x0301;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x0303;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x0302;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x0300;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x0301;
            DM(PIO_) = AR;
            call delay_I2C;
            rts;

I2CStop:    AR = 0x300;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x302;
            DM(PIO_) = AR;
            call delay_I2C;
            AR = 0x303;
            DM(PIO_) = AR;
            call delay_I2C;
            rts;

I2CLoadWord: SR = LSHIFT MR0 BY 8 (LO);
             MR1 = SR0;
             AY0 =0xFF00;
             AR = MR0 AND AY0;
             MR0 = AR;
             call I2CLoadByte;
             MR0 = MR1;

I2CLoadByte: CNTR = 9;        /* must be loaded into top 8 bits of MR0 */
I2CLoad:     AY0 = 0x8000;
             do I2CLoop until CE;
             AR = MR0 and AY0;
             SR = LSHIFT AR by -15 (LO);
             AY1 = 0x0300;
             AR = SR0 OR AY1;
             AX0 = AR;
             DM(PIO_) = AR;
             call delay_I2C;
             AY1 = 0x0302;
             AR = SR0 OR AY1;
             DM(PIO_) = AR;
             call delay_I2C;
             DM(PIO_) = AX0;
             call delay_I2C;
             SR = LSHIFT MR0 BY 1 (LO);
I2CLoop:     MR0 = SR0;
             rts;

{
        Square Root
                y = sqrt(x)

        Calling Parameters
                MR1 = MSW of x
                MR0 = LSW of x
                M3 = 1
                L3 = 0

        Return Values
                SR1 = y in 8.8 UNSIGNED format

        Altered Registers
                AX0,AY0,AY1,AR,MY0,MY1,MX0,MF,MR,SE,SR,I3

        Computation Time
                75 cycles (maximum)
}

{.CONST  base=H#0D49, sqrt2=H#5A82;}
#define base 0x0D49
#define sqrt2 0x5A82


.VAR/DM sqrt_coeff[5];

.INIT   sqrt_coeff : H#5D1D, H#A9ED, H#46D6, H#DDAA, H#072D;

.ENTRY  sqrt;

sqrt:   I3=^sqrt_coeff;                       {Pointer to coeff. buffer}
        SE=EXP MR1 (HI);                      {Check for redundant bits}
        SE=EXP MR0 (LO);
        AX0=SE, SR=NORM MR1 (HI);             {Remove redundant bits}
        SR=SR OR NORM MR0 (LO);
        MY0=SR1, AR=PASS SR1;
        IF EQ RTS;
        MR=0;
        MR1=base;                             {Load constant value}
        MF=AR*MY0 (RND), MX0=DM(I3,M3);       {MF = x**2}
        MR=MR+MX0*MY0 (SS), MX0=DM(I3,M3);    {MR = base + C1*x}
        CNTR=4;
        DO approx UNTIL CE;
                MR=MR+MX0*MF (SS), MX0=DM(I3,M3);
approx:         MF=AR*MF (RND);
        AY0=15;
        MY0=MR1, AR=AX0+AY0;                 {SE + 15 = 0?}
        IF NE JUMP scale;                    {No, compute sqrt(s)}
        SR=ASHIFT MR1 BY -6 (HI);
        RTS;
scale:  MR=0;
        MR1=sqrt2;                           {Load 1/sqrt(2)}
        MY1=MR1, AR=ABS AR;
        AY0=AR;
        AR=AY0-1;
        IF EQ JUMP pwr_ok;
        CNTR=AR;                             {Compute (1/sqrt(2))^(SE+15)}
        DO compute UNTIL CE;
compute:  MR=MR1*MY1 (RND);
pwr_ok: IF NEG JUMP frac;
        AY1=H#0080;                          {Load a 1 in 9.23 format}
        AY0=0;                               {Compute reciprocal of MR}
        DIVS AY1, MR1;
        DIVQ MR1; DIVQ MR1; DIVQ MR1;
        DIVQ MR1; DIVQ MR1; DIVQ MR1;
        DIVQ MR1; DIVQ MR1; DIVQ MR1;
        DIVQ MR1; DIVQ MR1; DIVQ MR1;
        DIVQ MR1; DIVQ MR1; DIVQ MR1;
        MX0=AY0;
        MR=0;
        MR0=H#2000;
        MR=MR+MX0*MY0 (US);
        SR=ASHIFT MR1 BY 2 (HI);
        SR=SR OR LSHIFT MR0 BY 2 (LO);
        RTS;
frac:   MR=MR1*MY0 (RND);
        SR=ASHIFT MR1 BY -6 (HI);
        RTS;

Center_:       call RegSave;
               MX1 = AR;
               i0 = MX1;
               l0 = 0;
               m0 = 1;
               CNTR = 128;
               AY0 = 0;
               AY1 = H#FFFF;
               AX0 = dm(i0,m0);
               do center2_loop UNTIL CE;
               AX1 = H#8000;
               AF = PASS AX1;
               AR = AX0+AF;
               AF = AR-AY0;
               if NOT AC jump center2_not_hi;
               AY0 = AR;
center2_not_hi: AF = AR-AY1;
               if AC jump center2_loop;
               AY1 = AR;
center2_loop:  AX0 = dm(i0,m0);
               AX0 = AY0;
               AR = AX0-AY1;
               AX1 = AR;
               SR = LSHIFT AR BY -1(LO);
               AF = SR0+AY1;
               AF = AF-1;
/*               AX1 = H#8000;
               AR = AX1+AF;
               MX0 = AR;
*/               i0 = MX1;
               m1 = 0;
               CNTR = 128;
               AX0 = dm(i0,m1);
               MY0 = 0;
               do center2_2 UNTIL CE;
               AR = AX0-AF;
               dm(i0,m0) = AR;
center2_2:     AX0 = dm(i0,m1);
               AY0 = H#8000;
               AR = AX1-AY0;
               call RegRestore;
               rts;

FM2_:          call RegSave;
               I0 = AR;
               I1 = AY1;
               AX0 = ^USB_BUFFER_;
               AY0 = dm(Buffer_Position);
               AR = ax0+ay0;
               I2 = ar;
               L2 = 0;
               M1 = 1;
               L0 = 0;
               L1 = 0;
               M3 = 1;     /* M3 & L3 are for the arctan */
               L3 = 0;
               CNTR = 128;
               do FM2_loop until CE;
               AY1 = DM(I0,M1);
               AX0 = DM(I0,M1);
               call FM;
					call FM_Filter8;
               DM(I2,M1) = AR;
               DM(I1,M1) = AR;
FM2_loop:      DM(I1,M1) = AR;
               call RegRestore;
               rts;

PSK_:          call RegSave;
               I0 = AR;
               I1 = AY1;
               I2 = ^USB_BUFFER_;
               L2 = 0;
               M1 = 1;
               L0 = 0;
               L1 = 0;
               M3 = 1;     /* M3 & L3 are for the arctan */
               L3 = 0;
               CNTR = 128;
               do PSK_loop until CE;
               AY1 = DM(I0,M1);
               AX0 = DM(I0,M1);
               call FM;
               DM(I2,M1) = AR;
               DM(I1,M1) = AR;
PSK_loop:      DM(I1,M1) = AR;
               call RegRestore;
               rts;

Convert_RTTY_To_Bits_: call RegSave;
                       I0 = AR;   /* 256 byte array */
                       I1 = AY1;
                       M1 = 1;
                       L0 = 0;
                       L1 = 0;
                       AX0 = 1;
                       AF = PASS AX0;
                       AY1 = 0;
                       AR = dm(rtty_samples_left);
                       CNTR = 128;
                       AX0 = DM(I0,M1);
                       do Convert_RTTY_Loop until CE;
                       AR = AR-AF;
                       if NE jump Convert_RTTY_Loop;
                       AR = AY1 + 1;
                       AY1 = AR;
                       DM(I1,M1) = AX0;
                       AR = rtty_samples_per_bit;
Convert_RTTY_Loop:     AX0 = DM(I0,M1);
                       AX0 = 0;
                       DM(I1,M1) = AX0;
                       dm(rtty_samples_left) = AR;
                       ar = ay1;
                       call RegRestore;  /* return number of bits processed*/
                       rts;

Convert_RTTY_To_Bits_2: call RegSave;
                        I0 = AR;   /* 256 byte array */
                        I1 = AY1;
                        M1 = 1;
                        L0 = 0;
                        L1 = 0;
                        AY1 = 0;
                        AX0 = 1;
                       MR = 0;
                        AF = pass AX0;
                        AY0 = dm(last_rtty_sample);
                        AX1 = dm(rtty_samples_left);
                        CNTR = 128;
                        do Convert_RTTY_Loop2 until CE;
                        AX0 = DM(I0,M1);
                        AR = AX1 + AF;
                        AX1 = AR;
                        AR = AX0 XOR AY0;
                        if GE jump Convert_RTTY_Loop2a;
                        AR = PASS AY0;
                        if GE jump was_high;
                        AR = -AX1;
                        AX1 = AR;
was_high:               DM(I1,M1) = AX1;
                        AX1 = 0;
                        AR = AY1+1;
                        AY1 = AR;
Convert_RTTY_Loop2a:    AY0 = AX0;
Convert_RTTY_Loop2:     AX0 = DM(I0,M1);
                       ax0 = 100;
                       DM(I1,M1) = AX0;
                       DM(Transfer_Data) = I1;
                       AR = AY1+1;
                       AY1 = AR;
                        dm(last_rtty_sample) = AY0;
                        AX0 = 0;
                        DM(I1,M1) = AX0;
                        dm(rtty_samples_left) = AX1;
                        AR = AY1;
                        call RegRestore;  /* return number of bits processed*/
                        rts;

FM3_:          call RegSave;
               M3 = 1;
               L3 = 0;
               AX0 = AR;
               call FM;
               call FM_Filter8;
               call RegRestore;
               rts;

FM_:           call RegSave;
               M3 = 1;
               L3 = 0;
               AX0 = AR;
               call FM;
               call RegRestore;
               rts;

FM:            AX1 = AY1;
               MR1 = AX0;
               SI = AX1;
               SR = ASHIFT SI by -9 (HI);
               AR = ABS SR1;
               AY0 = AR;
               AR = ABS AX0;
               AR = AR-AY0;
               AY0 = SR1;
               if LE jump fm_over;
               SI = AY1;
               SR = ASHIFT SI BY -7 (HI);
               AF = PASS SR1;
               AY0 = SR0;
               call sdivide;      /* AY0 = (AF,AY0)/AX0 */
tosmalladj:    AX1 = 0x0008;
               AR = AX1 + AY0;
               SI = AR;
               SR = ASHIFT SI by -4 (HI);
               AX1 = SR1;
               AR = ABS AX1;
               AY1 = 0xFF;
               AF = AR-AY1;
               if LE jump no_fm_over;
fm_over:       AR = 0xFF;
no_fm_over:    AY1 = ^arctan_data;
               AR = AR + AY1;
               I3 = AR;
               AX0 = DM(I3,M3);
               AR = PASS AY0;
               if GE jump Quad1or3;
               AR = -AX0;
               AX0 = AR;
Quad1or3:      AR = PASS MR1;
               if GE jump Quad1or2;
               AY1 = 0x8000;
               AR = AX0+AY1;
               rts;
Quad1or2:      AR = AX0;
               rts;

Mute_Samples_: call RegSave;
               I0 = AR;
               M0 = 1;
               L0 = 0;
               AX0 = 0;
               CNTR = 256;
               do Mute_Loop until CE;
Mute_Loop:     DM(I0,M0) = AX0;
               call RegRestore;
               rts;

.ENDMOD;

